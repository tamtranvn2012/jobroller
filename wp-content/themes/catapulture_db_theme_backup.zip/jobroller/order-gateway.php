<?php

$params = array (
	'order_template' => 'includes/forms/order/order-gateway.php',
);

jr_load_order_template( $params );
