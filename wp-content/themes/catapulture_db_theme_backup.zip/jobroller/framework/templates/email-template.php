<html>
<head>

</head>

<body>
	<?php echo $content; ?>
</body>
</html>
