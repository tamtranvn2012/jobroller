<?php

$params = array (
	'order_template' => 'includes/forms/order/order-checkout.php',
);

jr_load_order_template( $params );
